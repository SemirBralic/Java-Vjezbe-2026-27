//Napisati klasu Televizor sa atributima: brojKanala (int, mora biti >= 1), nazivKanala(String), jacinaTona(int, između 1-10). Potrebno je odraditi:
//Konstruktor koji inicijalizuje sve atribute. Getere i setere za sve atribute (sa provjerama da broj kanala >= 1 i jacina tona između 1-10). Metod pojacajTon() koji
//povećava jacinu tona za 1, ali ne može preći 10. Metod ispisi() koji ispisuje broj kanala, naziv kanala i trenutnu jacinu tona.
public class Televizor {

	private int brojKanala;
	private String nazivKanala;
	private int jacinaTona;
	
	public Televizor(int brojKanala,String nazivKanala,int jacinaTona) {
		setBrojKanala(brojKanala);
		this.nazivKanala = nazivKanala;
		setJacinaTona(jacinaTona);
	}

	public int getBrojKanala() {
		return brojKanala;
	}

	public void setBrojKanala(int brojKanala) {
		if (brojKanala>=1) {
			this.brojKanala = brojKanala;
		}
		else {
			System.out.println("Broj Kanala mora biti veći od 0");
			this.brojKanala=1;
		}
	}

	public String getNazivKanala() {
		return nazivKanala;
	}

	public void setNazivKanala(String nazivKanala) {
		this.nazivKanala = nazivKanala;
	}

	public int getJacinaTona() {
		return jacinaTona;
	}

	public void setJacinaTona(int jacinaTona) {
		if (jacinaTona >= 0 && jacinaTona <=10) {
		this.jacinaTona = jacinaTona;}
		else {
			if(jacinaTona<0) {
				this.jacinaTona=0;
			}
			if(jacinaTona>10) {
				this.jacinaTona=10;
			}
		}
		}
	
	public void pojacajTon() {
		
		if(this.jacinaTona<10) {
			this.jacinaTona++;
			System.out.println("Ton je povećan na: "+this.jacinaTona);
		}
		else {
			System.out.println("Ton je već na maksimumu.");
		}
		
	}

	public void ispisi() {
		System.out.println("Broj kanala: " + this.brojKanala + ", Naziv kanala: " + this.nazivKanala + ", Jacina tona: " + this.jacinaTona);
	}

	public void smanjiTon() {
		if(this.jacinaTona>0) {
			this.jacinaTona--;
			System.out.println("Ton je smanjen na: "+this.jacinaTona);
		}
		else {
			System.out.println("Ne može više");
		}
	}
	
}

	
	
	

	

