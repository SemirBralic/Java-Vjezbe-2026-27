import java.util.Scanner;
public class Faktorijel {

	public static void main(String[] args) {
		
	 int N, p = 1;
	 Scanner u = new Scanner(System.in);
	 System.out.println("Unesite broj N: ");
	 N = u.nextInt();
	 
	 if (N < 0)
		 System.out.println("Faktorijel negativnog broja ne postoji!");
	 else {
		 for (int i = 2; i<= N; i++)
		 p *= i;
		 
		 System.out.printf("%d! = %d", N, p);}
	 
	}

}
