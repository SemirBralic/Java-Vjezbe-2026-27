/* Program koji ilustruje štampanje na ekranu pomoću metode print */

//Deklaracija klase
public class PrviProgram {
//Deklaracija metode main
	public static void main(String[] args) {
		//Deklaracija i inicijalizacija promjenljivih
		int a = 5,b = 3,c;
		//Naredba koja rezultat sabiranja smješta u c
		c=a+b;
		//Ispis podataka na ekranu metodom print
		System.out.print("Rezultat sabiranja je: ");
		System.out.print(c);

	}

}
