
public class OkrugliSto {

	//za dva stola okrugla poznat je njihov poluprecnik. Napisati program kojim se stampa obim stola sa vecom povrsinom. r1 = 5, r2 = 7
	
	public static void main(String[] args) {
		
		int r1 = 5;
		int r2 = 7;
		
		double obim1 = 2 * r1 *Math.PI;
		double obim2 = 2 * r2 *Math.PI;
		
		double povrsina1 = r1 * r1 * Math.PI;
		double povrsina2 = r2 * r2 * Math.PI;
		
		if (povrsina1 > povrsina2) {
			System.out.println("Obim stola sa vecom povrsinom je: " + obim1);
		} else {
			System.out.println("Obim stola sa vecom povrsinom je: " + obim2);
		}

	}

}
