
public class KnjigaTest {

	public static void main(String[] args) {
		
		Knjiga knjiga = new Knjiga();
		
		knjiga.setIme("Na Drini ćuprija");
		knjiga.setBrojStrana(300);
		
		System.out.println("Ime knjige: " + knjiga.getIme());
		System.out.println("Broj strana: " + knjiga.getBrojStrana());

	}

}
