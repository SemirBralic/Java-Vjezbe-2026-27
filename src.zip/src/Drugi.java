import java.util.Scanner;
public class Drugi {

	public static void main(String[] args) {
		
		Scanner u = new Scanner(System.in);
		int x;
		System.out.println("Unesite broj x: ");
		x = u.nextInt();
		double f;
		
		if (x < 1)
			f = x*x; /*Math.pow(x,  2);*/
		else if (x >=1 && x < 5)
			f = 2-x;
		else
			f = (x*x*x-1)/5.0;
		System.out.printf("f(%d) = %.2f", x , f);  //.2 nam daje 2 decimale
		

	}

}
