
public class Dvocifrenibroj {
	
	//napisati program koji obbradjuje dvocifren broj na sljedeci nacin: Ako je prva cifra vece od druge stampati razliku prve i druge.
	//Ako je prva cifra manja od druge stampati zbir te dvije cifre. Ako su cifre iste stampati njihov proizvod

	public static void main(String[] args) {
		
		int broj = 57;
		
		int a = broj/10;
		int b = broj%10;
		
		if (a>b){
			int raz = a - b;
			System.out.println(raz);
		}
		else if (a<b){
			int zbir = a+b;
			System.out.println(zbir);
		}
		else {
			int proizvod = a*b;
			System.out.println(proizvod);
		}
		

	}

}
