package vjezba2p2;

public class Pravougaonik {

	public static void main(String[] args) {
		// DIMENZIJE PRAVOUGAONIKA SU 543 I 130. NAPISATI PROGRAM KOJI RACUNA KOLIKO KVADRATA STRANICE 65 JE MOGUCE IZREZATI IZ TOG PRAVOUGAONIKA
		
		double a = 543;
		double b = 130;
		double stranica = 65;
		
		double brojKvadrata = (a/stranica)*(b/stranica);
		
		System.out.println("U pravougaonik stranica: " +a+ "i: " +b+ " može da stane: " + brojKvadrata);

	}

}
