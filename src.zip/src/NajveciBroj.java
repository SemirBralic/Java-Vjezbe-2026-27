import java.util.Scanner;

//Korisnik unosi tri broja naci najveci i najmanji od njih i prikazati ih korisniku

public class NajveciBroj {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Unesite prvi broj: ");
		int broj1 = sc.nextInt();
		
		System.out.println("Unesite drugi broj: ");
		int broj2 = sc.nextInt();
		
		System.out.println("Unesite drugi broj: ");
		int broj3 = sc.nextInt();
		
		if (broj1 > broj2 && broj1 > broj3) {
			System.out.println("Najveci broj je: " + broj1);
		}else if (broj2 > broj1 && broj2 > broj3) {
			System.out.println("Najveci broj je: " + broj2);
		}
		else if (broj3 > broj1 && broj3 > broj2)
			System.out.println("Najveci broj je: " + broj3);
		else
			System.out.println("Svi brojevi su jednaki");
		
		if (broj1 < broj2 && broj1 < broj3) {
			System.out.println("Najmanji broj je: " + broj1);
		}else if (broj2 < broj1 && broj2 < broj3) {
			System.out.println("Najmanji broj je: " + broj2);
		}
		else if (broj3 < broj1 && broj3 < broj2)
			System.out.println("Najmanj broj je: " + broj3);
		else
			System.out.println("Svi brojevi su jednaki");

	}

}
