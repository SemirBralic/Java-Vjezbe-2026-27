package vjezba1;

public class Vjezbe1 {

	public static void main(String[] args) {
		
		/*short a = 32767, b=1, c;
		c= (short)(a+b);
		System.out.println(c);*/
		
		
		/*int A;
		float B;
		A=5;
		B=5*(float)A/7;
		System.out.println(B);*/
		
		
		/*boolean t, a=true,b=false,i,j;
		t=a&b;
		i= !(t==true);
		j=(i)? i:t;*/

		
		/*boolean t;
		int a = 3, b = -1;
		t = (a<<2==--b)&(b==a++);     // Kada stavimo dva && ili || ako prvi argument nam da odgovor ono ce preskociti drugi argument, 
		t = (a<<2!=--b) || (b==++a);  //a kod & i | ona ce ispratiti oba argumenta bilo šta
		System.out.println(t);*/
		
		
		/*int a=3,b=7,c=4;
		int nv=0;
		
				
		if (a>b && a>c)             //najveci broj
			nv=a;
		else if(c>a && c>b)
			nv=c;
		else
			nv=b;
		System.out.println(nv);*/
		
		//Jedan manje if za prosli zadatak
		
		/*nv=a;
	      if (nv < b)
	      	nv=b;
	      if (nv < c)
	      	nv=c;*
	      	*/
		
		
		
		
		
	}

}
