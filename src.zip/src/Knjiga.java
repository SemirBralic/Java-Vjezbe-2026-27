
public class Knjiga {
	
	private String ime;
	private int brojStrana;
	
	public String getIme() {
		return ime;
		}
	
	public void setIme(String s) {
		ime = s;
	}
	
	public int getBrojStrana() {
		return brojStrana;
	}
	public void setBrojStrana(int n) {
		brojStrana = n;
	}
}
