package vjezba2p3;

public class Televizor {

	public static void main(String[] args) {
		// Napisati program koji racuna povrsinu ekrana monitora pravougaonog oblika cija je dijagonala d=50 a odnos stranica 16:9
		
		double d = 50;
		double asp16 = 16;
		double asp9 = 9;
		
		double k = Math.sqrt(d*d/(asp16*asp16+asp9*asp9));
		
		double a = asp16 * k;
		double b = asp9 * k;
		
		double povrsina = a * b;
		
		System.out.println("površina pravougaonika je: " + povrsina);
		
		

	}

}
