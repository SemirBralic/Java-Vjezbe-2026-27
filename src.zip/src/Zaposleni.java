//Kreirati klasu zaposleni koja ima sljedeće atribute: ime, prezime, godine_staža, plata.
//Voditi računa koji tipovi podataka se vezuju za navedene atribute. Obavezno je kreirati konstruktor kojim se objekat klase može kreirati.
//Kreirati getter i setter metode kojima se može pristupiti određenom atributa, kao i eventualno taj atribut izmijeniti (pomoću seter metode).
//Klasa zaposleni mora da sadrži metodu koja vrši ispisivanje zaposlenih (ime i prezime, godine staza). Kreirati makar 3 objekata klase zaposleni i
//testirati getter i setter metode, kao i ispis zaposlenih (ispis objekta klase). U klasi Zaposleni potrebno je napraviti metodu koja će ispisati ime 
//zaposlenog koji ima najveću platu. Potrebno je dodati i metodu koja će provjeriti iznos plate i ako je manja od 800 uvećaće je 6% u slučaju da zaposleni ima 
//preko 10 godine staža
public class Zaposleni {

	private String ime;
	private String prezime;
	private int godine_staza;
	private double plata;
	public Zaposleni(String ime, String prezime, int godine_staza, double plata) {
		this.ime = ime;       //this koristimo kad imamo vrijednost bez ikakvih uslova, a set koristimo ako imamo neku uslov koju moramo da ispunimo
		this.prezime = prezime;
		this.godine_staza = godine_staza;
		this.plata = plata;
	}
	public String getIme() {
		return ime;
	}
	public void setIme(String ime) {
		this.ime = ime;
	}
	
	public String getPrezime() {
		return prezime;
	}
	public void setPrezime(String prezime) {
		this.prezime = prezime;
	}
	
	public int getGodine_staza() {
		return godine_staza;
	}
	public void setGodine_staza(int godine_staza) {
		if(godine_staza<0) {
			System.out.println("ne može ovo");
			this.godine_staza = 1;
		}
		else{
			this.godine_staza = godine_staza;
		}
	}
	
	public double getPlata() {
		return plata;
	}
	public void setPlata(double plata) {
		this.plata = plata;
	}
	
	public void ispisi() {
		System.out.println("Ime: " + ime + ", Prezime: " + prezime + ", Godine staža: " + godine_staza + ", Plata: " + plata);
	}
	
	
	
	public void povecajPlatu() {
		if(this.plata<800 && this.godine_staza>10) {
			this.plata = this.plata * 1.06;
			System.out.println("Nova plata je: " + this.plata);
		}else {
			System.out.println("Nemate uslove za veću platu");
		}
	}
	
	public static void najvećaPlata(Zaposleni z1, Zaposleni z2, Zaposleni z3) {

        Zaposleni najveci = z1;

        if (z2.plata > najveci.plata) {
            najveci = z2;
        }

        if (z3.plata > najveci.plata) {
            najveci = z3;
        }

        System.out.println("Zaposleni sa najvecom platom je: " + najveci.ime + " " + najveci.prezime);
    }
	
}
