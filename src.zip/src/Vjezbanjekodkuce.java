import java.util.Scanner;
public class Vjezbanjekodkuce {
//Koliko kvadrata odredjene stranice moze u pravougaonik
	public static void main(String[] args) {
		
		Scanner sc = new Scanner (System.in);
		double a,b,stranica;
		System.out.println("Unesite dužine stranica a,b pravougaonika i zatim unesite dužinu stranice kvadrata: ");
		a = sc.nextDouble();
		b = sc.nextDouble();
		stranica = sc.nextDouble();
		
		double brojKvadrata = (a/stranica)*(b/stranica);
		System.out.println("Može nam stati "+ brojKvadrata +" kvadrata u pravougaoniku čije su stranice: "+ a + " i "+ b);
		
		
	}

}
