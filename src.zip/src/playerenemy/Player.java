package playerenemy;
//Kreirati klasu Player sa atributima: x,y (pozicija igrača integer), width, height (dimenzije, integer), health (životni bodovi, integer, između 0 i 100).
//Kreirati klasu Enemy sa atributima: x,y (pozicija neprijatelja, integer), width, height (dimenzije, integer), damage (vrijednost napada, integer, između 0 i 100).
//Obje klase trebaju imati konstruktor za postavljanje vrijednosti, privatne atribute i odgovarajuće getere i setere (sa prvojerama za health i damage). Kolajderi kod 
//obije klase su pravougaonici, dok su x i y kordinate donje lijeve ivice kod oba objekta. Napraviti metodu u glavnoj public klasi Game checkCollision (Playr p, Enemy e)
//koja provjerava da li se igrač i neprijatelj preklapaju (sudar). Ako dođe do sudara metod decreaseHealth(Player p, Enemy e) smanjuje vrijednost health-a igrača za 
//damage vrijednost neprijatelja (ne smije pasti ispod0). Testirati kreiranjem jednog player-a (ne smije pasti ispod 0). Testirati kreiranjem jednog player-a i dva enemy
//objekta. Napomena: Testiranje radite u public klasi Game (tako nazvati klasu pri kreiranju fajla, a ostale za ostale klase ne treba koristiti public keyword ispred class
//riječi).
public class Player {
	private int x;
	private int y;
	private int width;
	private int height;
	private int health;
	
	public Player(int x, int y, int width, int height, int health) {
		this.x = x;
		this.y = y;
		this.width = width;
		this.height = height;
		setHealth(health);
	}

	public int getX() {
		return x;
	}

	public void setX(int x) {
		this.x = x;
	}

	public int getY() {
		return y;
	}

	public void setY(int y) {
		this.y = y;
	}

	public int getWidth() {
		return width;
	}

	public void setWidth(int width) {
		this.width = width;
	}

	public int getHeight() {
		return height;
	}

	public void setHeight(int height) {
		this.height = height;
	}

	public int getHealth() {
		return health;
	}

	public void setHealth(int health) {
		if (health < 0) {
			this.health = 0;
		} else if (health > 100) {
			this.health = 100;
		} else {
			this.health = health;
		}
	}
}
