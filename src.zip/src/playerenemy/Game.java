package playerenemy;

public class Game {

	public static boolean checkCollision(Player p, Enemy e) { // Metoda koja ce provjeriti hitboxove plejera i enemija i proveriti da li se preklapaju.
        if (p.getX() < e.getX() + e.getWidth()
                && p.getX() + p.getWidth() > e.getX()
                && p.getY() < e.getY() + e.getHeight()
                && p.getY() + p.getHeight() > e.getY()) {
        	
        	return true; //ako se preklaaju daju true
        }
		
        return false; //inace ce dati false
        
	}
	
	public static void decreaseHealth(Player p, Enemy e) {
		int noviHealth = p.getHealth() - e.getDamage();
		
		if (noviHealth<0) {
			noviHealth=0;
		}
		
		p.setHealth(noviHealth);
		
	}

	public static void main(String[] args) {
		
		Player p = new Player(0,0,50,50,100); //1.x koordinata; 2. y koordinata; 3. sirina; 4. visina; 5. hp
		
		Enemy e1 = new Enemy(30,30,40,40,20); //1. x koordinata; 2. y koordinata; 3. sirina; 4. visina; 5. damage
		Enemy e2 = new Enemy(100,100,30,30,50);
		
		if (checkCollision(p, e1)) {
			System.out.println("Player i Enemy hitboxovi se preklapaju");
			decreaseHealth(p, e1);
		}
		else {
			System.out.println("Ne diraju im se hitboxovi");
		}
		
		System.out.println("HP igrača: " + p.getHealth()); //printamo rezultat plejerovog hp-a
	}
	
}
