import java.util.Scanner;

public class Stepenovanje {

	//Napisati program koji računa x na n koristeći petlju
	
	public static void main(String[] args) {
		  Scanner sc = new Scanner(System.in);

	        System.out.print("Unesite x: ");
	        int x = sc.nextInt();

	        System.out.print("Unesite n: ");
	        int n = sc.nextInt();

	        int rezultat = 1;

	        for (int i = 1; i <= n; i++) {
	            rezultat = rezultat * x;
	        }

	        System.out.println(x + " na " + n + " = " + rezultat);
	}

}
