
public class ZaposleniTest {

	//Umesto da kreiramo novu klasu kod možemo odje da kuckamo looool.
	
	public static void main(String[] args) {
		
		Zaposleni z1 = new Zaposleni("Haris","Sutović",42,30.00);
		Zaposleni z2 = new Zaposleni("Semir","Bralić",5,10000.00);
		Zaposleni z3 = new Zaposleni("Neko","Veković",12,400.00);
		
		z1.ispisi();
		z2.ispisi();
		z3.ispisi();
		
		System.out.println("Plata Harisova: "+ z1.getPlata());
		z1.setPlata(500.00);
		System.out.println("Nova harkova plata: "+z1.getPlata());
		
		z3.povecajPlatu();
		System.out.println(z3.getPlata());
		
		Zaposleni.najvećaPlata(z1, z2, z3);
		
	}

}
