
public class TelevizorTest {

	public static void main(String[] args) {
		
		Televizor tv1 = new Televizor(5,"RTS", 9);
		Televizor tv2 = new Televizor(3,"TLC", 4);
		
		tv1.ispisi();
		tv2.pojacajTon();
		tv1.smanjiTon();
		

	}

}
