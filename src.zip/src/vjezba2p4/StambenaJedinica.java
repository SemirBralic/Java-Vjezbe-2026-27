package vjezba2p4;

import java.util.Scanner;

//dat je petocifreni broj koji predstavlja broj stambene jedinice.
//Na osnovu zadatog broja potrebno je odrediti sprat na kojeme se nalazi stambena jedinica. 
//Poznato je da se to moze otkriti kada se na vrijednost predposljednje cifre zadatog broja, doda posljednja. Stampati taj broja

public class StambenaJedinica {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Unesite petocifren broj: ");
        int broj = sc.nextInt();

        int posljednja = broj % 10;
        int pretposljednja = (broj / 10) % 10;

        int sprat = pretposljednja + posljednja;

        System.out.println("Stambena jedinica se nalazi na " + sprat + ". spratu.");
    }
}