import java.util.Scanner;

public class Prvi {

	public static void main(String[] args) {
		
		int a,b,c,min,max;
		
		Scanner u = new Scanner(System.in);
		System.out.println(" Unesite broj a: ");
		a = u.nextInt();
		System.out.println("Unesite broj b:" );
		b = u.nextInt();
		System.out.println("Unesite broj c: ");
		c = u.nextInt();
		
		min = a;
		max = a;
		
		if (min > b)
			min = b;
		if (min > c)
			min = c;
		System.out.println("Najmanji broj je: " + min);
		
		if (max < b)
			max = b;
		if (max < c);
			max = c;
		System.out.println("Najveci broj je: " + max);
		
	}

}
