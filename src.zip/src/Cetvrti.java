//Dat je prirodan broj n, proveriti koja cifra ima najvecu tezinu, a koja najmanja i da li su one jednake
import java.util.Scanner;
public class Cetvrti {

	public static void main(String[] args) {
		Scanner unos = new  Scanner(System.in);
		int N, cifnv, cifnm;
		System.out.println("Unesite prirodan broj n: ");
		N = unos.nextInt();
		cifnv = cifnm = N % 10;
		N = N /10;
		while (N != 0) {
			cifnv = N % 10;
			N = N/10;
		}
		System.out.println("Najteza cifra je: " + cifnv + " a najlaksa cifra je: " + cifnm);
		
		if (cifnv == cifnm) {
			System.out.println("Najteza i najlaksa cifra su jednake");
		} else {
			System.out.println("Najteza i najlaksa cifra nisu jednake");
		}
	}

}
